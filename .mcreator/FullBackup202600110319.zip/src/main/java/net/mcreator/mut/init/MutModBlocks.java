/*
 *    MCreator note: This file will be REGENERATED on each build.
 */
package net.mcreator.mut.init;

import net.neoforged.neoforge.registries.DeferredRegister;
import net.neoforged.neoforge.registries.DeferredBlock;

import net.minecraft.world.level.block.Block;

import net.mcreator.mut.block.SteelDebrisBlock;
import net.mcreator.mut.block.NetherDeepIronOreBlockBlock;
import net.mcreator.mut.block.GildingDebrisBlock;
import net.mcreator.mut.block.BlueDiamondDebrisBlock;
import net.mcreator.mut.MutMod;

public class MutModBlocks {
	public static final DeferredRegister.Blocks REGISTRY = DeferredRegister.createBlocks(MutMod.MODID);
	public static final DeferredBlock<Block> STEEL_DEBRIS;
	public static final DeferredBlock<Block> BLUE_DIAMOND_DEBRIS;
	public static final DeferredBlock<Block> NETHER_DEEP_IRON_ORE_BLOCK;
	public static final DeferredBlock<Block> GILDING_DEBRIS;
	static {
		STEEL_DEBRIS = REGISTRY.register("steel_debris", SteelDebrisBlock::new);
		BLUE_DIAMOND_DEBRIS = REGISTRY.register("blue_diamond_debris", BlueDiamondDebrisBlock::new);
		NETHER_DEEP_IRON_ORE_BLOCK = REGISTRY.register("nether_deep_iron_ore_block", NetherDeepIronOreBlockBlock::new);
		GILDING_DEBRIS = REGISTRY.register("gilding_debris", GildingDebrisBlock::new);
	}
	// Start of user code block custom blocks
	// End of user code block custom blocks
}