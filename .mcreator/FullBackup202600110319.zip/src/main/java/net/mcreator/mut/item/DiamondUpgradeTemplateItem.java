package net.mcreator.mut.item;

import net.minecraft.world.item.Item;

public class DiamondUpgradeTemplateItem extends Item {
	public DiamondUpgradeTemplateItem() {
		super(new Item.Properties());
	}
}