package net.mcreator.mut.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class SteelUpgradeTemplateItem extends Item {
	public SteelUpgradeTemplateItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}
}