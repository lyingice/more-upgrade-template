/*
*	MCreator note: This file will be REGENERATED on each build.
*/
package net.mcreator.mut.init;

import net.neoforged.neoforge.event.village.VillagerTradesEvent;
import net.neoforged.neoforge.common.BasicItemListing;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.bus.api.SubscribeEvent;

import net.minecraft.world.item.Items;
import net.minecraft.world.item.ItemStack;

@EventBusSubscriber
public class MutModTrades {
	@SubscribeEvent
	public static void registerTrades(VillagerTradesEvent event) {
		if (event.getType() == MutModVillagerProfessions.TEMPLATE_VENDOR.get()) {
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 20), new ItemStack(MutModItems.STONE_UPGRADE_TEMPLATE.get()), 5, 5, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 40), new ItemStack(MutModItems.IRON_UPGRADE_TEMPLATE.get()), 5, 8, 0.05f));
			event.getTrades().get(1).add(new BasicItemListing(new ItemStack(Items.EMERALD, 60), new ItemStack(MutModItems.DIAMOND_UPGRADE_TEMPLATE.get()), 5, 10, 0.05f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(Items.EMERALD, 13), new ItemStack(MutModItems.STONE_UPGRADE_TEMPLATE.get()), 4, 10, 0.05f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(Items.EMERALD, 25), new ItemStack(MutModItems.IRON_UPGRADE_TEMPLATE.get()), 4, 15, 0.05f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(Items.EMERALD, 35), new ItemStack(MutModItems.DIAMOND_UPGRADE_TEMPLATE.get()), 4, 15, 0.05f));
			event.getTrades().get(2).add(new BasicItemListing(new ItemStack(Items.EMERALD, 14), new ItemStack(MutModItems.IRON_ARMOR_REBUILD_TEMPLATE.get()), 10, 5, 0.05f));
			event.getTrades().get(3).add(new BasicItemListing(new ItemStack(Items.EMERALD, 46), new ItemStack(MutModItems.DIAMOND_ARMOR_REBUILD_TEMPLATE.get()), 10, 5, 0.05f));
		}
	}
}