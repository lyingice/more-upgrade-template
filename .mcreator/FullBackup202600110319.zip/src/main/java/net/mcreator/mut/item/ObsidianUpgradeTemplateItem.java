package net.mcreator.mut.item;

import net.minecraft.world.item.Item;

public class ObsidianUpgradeTemplateItem extends Item {
	public ObsidianUpgradeTemplateItem() {
		super(new Item.Properties());
	}
}