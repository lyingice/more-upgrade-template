package net.mcreator.mut.item;

import net.minecraft.world.item.Item;

public class NetheriteObsidianUpgradeTemplateItem extends Item {
	public NetheriteObsidianUpgradeTemplateItem() {
		super(new Item.Properties());
	}
}