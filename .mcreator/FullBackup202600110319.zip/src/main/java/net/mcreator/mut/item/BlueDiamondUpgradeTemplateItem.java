package net.mcreator.mut.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class BlueDiamondUpgradeTemplateItem extends Item {
	public BlueDiamondUpgradeTemplateItem() {
		super(new Item.Properties().rarity(Rarity.UNCOMMON));
	}
}