package net.mcreator.mut.item;

import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Item;

public class NetherStarUpgradeTemplateItem extends Item {
	public NetherStarUpgradeTemplateItem() {
		super(new Item.Properties().rarity(Rarity.EPIC));
	}
}