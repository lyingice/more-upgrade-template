package net.mcreator.mut.item;

import net.minecraft.world.item.Item;

public class IronUpgradeTemplateItem extends Item {
	public IronUpgradeTemplateItem() {
		super(new Item.Properties());
	}
}